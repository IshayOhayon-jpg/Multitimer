package com.example.multitimer.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.notify.TimerNotifier
import com.example.multitimer.util.DebugLogger

/** Handles the Pause / Resume / Cancel buttons on the running-timer notifications. */
class TimerActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(TimerNotifier.EXTRA_TIMER_ID, -1)
        if (id < 0) return
        DebugLogger.log("Notif", "action=${intent.action} id=$id")
        val repo = TimerRepository.get(context)
        when (intent.action) {
            TimerNotifier.ACTION_PAUSE -> repo.pause(id)
            TimerNotifier.ACTION_RESUME -> repo.start(id)
            TimerNotifier.ACTION_CANCEL -> repo.reset(id) // back to idle with full duration
        }
    }
}
