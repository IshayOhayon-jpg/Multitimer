package com.example.multitimer.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** App settings persisted in SharedPreferences (local only). */
class SettingsRepository private constructor(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val _debugMode = MutableStateFlow(prefs.getBoolean(KEY_DEBUG, false))
    val debugMode: StateFlow<Boolean> = _debugMode.asStateFlow()

    /** Selected notification sound URI as a string, or null for the system default. */
    private val _ringtoneUri = MutableStateFlow(prefs.getString(KEY_RINGTONE, null))
    val ringtoneUri: StateFlow<String?> = _ringtoneUri.asStateFlow()

    fun setDebugMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_DEBUG, enabled).apply()
        _debugMode.value = enabled
    }

    fun setRingtoneUri(uri: String?) {
        prefs.edit().apply {
            if (uri == null) remove(KEY_RINGTONE) else putString(KEY_RINGTONE, uri)
        }.apply()
        _ringtoneUri.value = uri
    }

    companion object {
        private const val PREFS = "settings_store"
        private const val KEY_DEBUG = "debug_mode"
        private const val KEY_RINGTONE = "ringtone_uri"

        @Volatile
        private var instance: SettingsRepository? = null

        fun get(context: Context): SettingsRepository =
            instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
    }
}
