package com.example.multitimer.ringing

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.multitimer.R
import com.example.multitimer.data.SettingsRepository
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.util.DebugLogger

/**
 * Foreground service that loops the selected notification sound while any timer is
 * ringing, and posts the full-screen "Turn Off" notification.
 */
class RingingService : Service() {

    private lateinit var repo: TimerRepository
    private var ringtone: Ringtone? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repo = TimerRepository.get(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISMISS -> handleDismiss()
            else -> handleRing()
        }
        return START_NOT_STICKY
    }

    private fun handleRing() {
        // Must be promoted to foreground right away after startForegroundService().
        startForeground(
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
        )
        if (repo.ringingTimers().isEmpty()) {
            DebugLogger.log("Service", "nothing ringing; stopping")
            stopRinging()
            return
        }
        acquireWakeLock()
        startSound()
    }

    private fun handleDismiss() {
        val remaining = repo.dismissOldestRinging()
        DebugLogger.log("Service", "turn off pressed; $remaining still ringing")
        if (remaining == 0) {
            stopRinging()
        } else {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIFICATION_ID, buildNotification())
        }
    }

    private fun stopRinging() {
        stopSound()
        releaseWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ------------------------------------------------------------------ sound

    private fun startSound() {
        if (ringtone != null) return

        val configured = SettingsRepository.get(this).ringtoneUri.value?.let { Uri.parse(it) }
        val default = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val rt = (configured?.let { RingtoneManager.getRingtone(this, it) })
            ?: RingtoneManager.getRingtone(this, default)
        if (rt == null) {
            DebugLogger.log("Service", "could not create ringtone for $configured / $default")
            return
        }
        rt.audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        rt.isLooping = true
        rt.play()
        ringtone = rt
        DebugLogger.log("Service", "sound started uri=${configured ?: default}")
    }

    private fun stopSound() {
        ringtone?.let {
            runCatching { it.stop() }
            DebugLogger.log("Service", "sound stopped")
        }
        ringtone = null
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "multitimer:ringing").apply {
            acquire()
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ----------------------------------------------------------- notification

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel),
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            setSound(null, null)       // the sound is played by this service, looping
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val label = repo.ringingTimers().firstOrNull()?.label?.takeIf { it.isNotBlank() }
        val openIntent = Intent(this, RingingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(label ?: getString(R.string.notif_text))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
    }

    override fun onDestroy() {
        stopSound()
        releaseWakeLock()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "timer_ringing"
        private const val NOTIFICATION_ID = 42
        private const val ACTION_RING = "com.example.multitimer.action.RING"
        private const val ACTION_DISMISS = "com.example.multitimer.action.DISMISS"

        fun ringIntent(context: Context): Intent =
            Intent(context, RingingService::class.java).setAction(ACTION_RING)

        fun dismissIntent(context: Context): Intent =
            Intent(context, RingingService::class.java).setAction(ACTION_DISMISS)
    }
}
