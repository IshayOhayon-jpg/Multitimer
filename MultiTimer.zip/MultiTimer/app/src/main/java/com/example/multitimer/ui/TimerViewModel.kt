package com.example.multitimer.ui

import android.app.Application
import android.media.RingtoneManager
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.example.multitimer.data.SettingsRepository
import com.example.multitimer.data.TimerItem
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.data.TimerState
import com.example.multitimer.util.DebugLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Which timer the configuration sheet is editing. */
sealed interface Editor {
    data object New : Editor
    data class Existing(val id: Int) : Editor
}

class TimerViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = TimerRepository.get(app)
    private val settings = SettingsRepository.get(app)

    val timers: StateFlow<List<TimerItem>> = repo.timers
    val debugMode: StateFlow<Boolean> = settings.debugMode
    val ringtoneUri: StateFlow<String?> = settings.ringtoneUri

    private val _editor = MutableStateFlow<Editor?>(null)
    val editor: StateFlow<Editor?> = _editor.asStateFlow()

    // ------------------------------------------------------------ config sheet

    fun openNew() { _editor.value = Editor.New }
    fun openExisting(id: Int) { _editor.value = Editor.Existing(id) }
    fun closeEditor() { _editor.value = null }

    /** "Set": save the duration/label for the edited timer and start it. */
    fun saveAndStart(label: String, durationSeconds: Long) {
        val id = (_editor.value as? Editor.Existing)?.id
        repo.saveAndStart(id, label, durationSeconds)
        _editor.value = null
    }

    // ---------------------------------------------------------- timer controls

    fun toggle(timer: TimerItem) {
        when (timer.state) {
            TimerState.RUNNING -> repo.pause(timer.id)
            TimerState.IDLE, TimerState.PAUSED -> repo.start(timer.id)
            TimerState.RINGING -> Unit // handled by the ringing screen
        }
    }

    fun reset(id: Int) = repo.reset(id)
    fun delete(id: Int) = repo.delete(id)

    // ---------------------------------------------------------------- settings

    fun setDebugMode(enabled: Boolean) {
        if (enabled) {
            settings.setDebugMode(true)
            DebugLogger.log("Settings", "Debug mode enabled")
        } else {
            DebugLogger.log("Settings", "Debug mode disabled")
            settings.setDebugMode(false)
        }
    }

    /** [uri] == null or the system default URI means "use the system default". */
    fun setRingtone(uri: Uri?) {
        val default = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val value = if (uri == null || uri == default) null else uri.toString()
        settings.setRingtoneUri(value)
        DebugLogger.log("Settings", "Notification sound set to ${value ?: "system default"}")
    }
}
