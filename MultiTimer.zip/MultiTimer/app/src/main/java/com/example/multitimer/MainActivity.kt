package com.example.multitimer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.multitimer.data.TimerState
import com.example.multitimer.ringing.RingingActivity
import com.example.multitimer.ui.MainScreen
import com.example.multitimer.ui.SettingsScreen
import com.example.multitimer.ui.TimerViewModel
import com.example.multitimer.ui.theme.MultiTimerTheme

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* nothing to do */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Needed so the ringing notification / full-screen "Turn Off" screen can be shown.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MultiTimerTheme {
                AppRoot()
            }
        }
    }
}

@Composable
private fun AppRoot(vm: TimerViewModel = viewModel()) {
    var showSettings by rememberSaveable { mutableStateOf(false) }
    val timers by vm.timers.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // If the app is in the foreground when a timer finishes, show the ringing screen at once.
    val anyRinging = timers.any { it.state == TimerState.RINGING }
    LaunchedEffect(anyRinging) {
        if (anyRinging) {
            context.startActivity(
                Intent(context, RingingActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    if (showSettings) {
        BackHandler { showSettings = false }
        SettingsScreen(vm = vm, onBack = { showSettings = false })
    } else {
        MainScreen(vm = vm, onOpenSettings = { showSettings = true })
    }
}
