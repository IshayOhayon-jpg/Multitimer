package com.example.multitimer.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.multitimer.R
import com.example.multitimer.util.DebugLogger

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: TimerViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val debug by vm.debugMode.collectAsStateWithLifecycle()
    val ringtoneUri by vm.ringtoneUri.collectAsStateWithLifecycle()

    val pickerTitle = stringResource(R.string.settings_sound_picker_title)
    val pickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val picked = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            vm.setRingtone(picked)
        }
    }

    val soundName = remember(ringtoneUri) { soundTitle(context, ringtoneUri) }
    val logPath = remember(debug) { DebugLogger.logDirectory(context)?.absolutePath.orEmpty() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_sound)) },
                supportingContent = { Text(soundName) },
                leadingContent = { Icon(Icons.Filled.Notifications, contentDescription = null) },
                modifier = Modifier.clickable {
                    pickerLauncher.launch(buildPickerIntent(pickerTitle, ringtoneUri))
                },
            )
            HorizontalDivider()
            ListItem(
                headlineContent = { Text(stringResource(R.string.settings_debug)) },
                supportingContent = {
                    Text(
                        if (debug) stringResource(R.string.settings_debug_on, logPath)
                        else stringResource(R.string.settings_debug_off)
                    )
                },
                leadingContent = { Icon(Icons.Filled.BugReport, contentDescription = null) },
                trailingContent = { Switch(checked = debug, onCheckedChange = vm::setDebugMode) },
            )
        }
    }
}

/** System picker limited to the device's out-of-the-box notification sounds. */
private fun buildPickerIntent(title: String, currentUri: String?): Intent {
    val default = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    return Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, title)
        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
        putExtra(RingtoneManager.EXTRA_RINGTONE_DEFAULT_URI, default)
        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, currentUri?.let(Uri::parse) ?: default)
    }
}

private fun soundTitle(context: Context, uriString: String?): String {
    val uri = uriString?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    val title = runCatching { RingtoneManager.getRingtone(context, uri)?.getTitle(context) }.getOrNull()
    val defaultLabel = context.getString(R.string.settings_sound_default)
    return when {
        uriString == null -> if (title.isNullOrBlank()) defaultLabel else "$defaultLabel ($title)"
        else -> title ?: context.getString(R.string.settings_sound_unknown)
    }
}
