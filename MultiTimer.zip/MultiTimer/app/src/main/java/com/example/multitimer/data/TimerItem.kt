package com.example.multitimer.data

import kotlin.math.max

enum class TimerState { IDLE, RUNNING, PAUSED, RINGING }

/**
 * A single timer.
 *
 * - [durationSeconds] is the configured length (shown as hours / minutes / seconds).
 * - [remainingSeconds] is authoritative while IDLE or PAUSED.
 * - [endAtMillis] (wall-clock) is authoritative while RUNNING; use [remainingAt].
 */
data class TimerItem(
    val id: Int,
    val label: String = "",
    val durationSeconds: Long,
    val state: TimerState = TimerState.IDLE,
    val remainingSeconds: Long = durationSeconds,
    val endAtMillis: Long = 0L,
    val ringingSinceMillis: Long = 0L,
) {
    val hours: Int get() = (durationSeconds / 3600).toInt()
    val minutes: Int get() = ((durationSeconds % 3600) / 60).toInt()
    val seconds: Int get() = (durationSeconds % 60).toInt()

    /** Remaining whole seconds (rounded up) at the given wall-clock time. */
    fun remainingAt(nowMillis: Long): Long = when (state) {
        TimerState.RUNNING -> max(0L, (endAtMillis - nowMillis + 999L) / 1000L)
        TimerState.RINGING -> 0L
        else -> remainingSeconds
    }
}
