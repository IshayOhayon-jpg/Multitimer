package com.example.multitimer.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.example.multitimer.util.DebugLogger

/** Schedules / cancels one exact wake-up alarm per timer. */
object AlarmScheduler {

    const val ACTION_TIMER_FIRED = "com.example.multitimer.action.TIMER_FIRED"
    const val EXTRA_TIMER_ID = "timer_id"

    fun schedule(context: Context, timerId: Int, triggerAtMillis: Long) {
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(context, timerId, create = true) ?: return
        try {
            if (am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                // Should not happen with USE_EXACT_ALARM; degrade gracefully anyway.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
                DebugLogger.log("Alarm", "Exact alarms unavailable; used inexact for id=$timerId")
            }
            DebugLogger.log("Alarm", "scheduled id=$timerId at=$triggerAtMillis")
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            DebugLogger.log("Alarm", "SecurityException; fell back to inexact for id=$timerId", e)
        }
    }

    fun cancel(context: Context, timerId: Int) {
        val am = context.getSystemService(AlarmManager::class.java)
        val pi = pendingIntent(context, timerId, create = false) ?: return
        am.cancel(pi)
        pi.cancel()
        DebugLogger.log("Alarm", "cancelled id=$timerId")
    }

    private fun pendingIntent(context: Context, timerId: Int, create: Boolean): PendingIntent? {
        val intent = Intent(context, AlarmReceiver::class.java)
            .setAction(ACTION_TIMER_FIRED)
            .putExtra(EXTRA_TIMER_ID, timerId)
        val flags = PendingIntent.FLAG_IMMUTABLE or
            if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        // The request code (timerId) keeps each timer's PendingIntent distinct.
        return PendingIntent.getBroadcast(context, timerId, intent, flags)
    }
}
