package com.example.multitimer.ringing

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.multitimer.R
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.data.TimerState
import com.example.multitimer.ui.theme.MultiTimerTheme
import com.example.multitimer.util.timerTitle
import kotlinx.coroutines.launch

/**
 * Full-screen layover shown when a timer rings. Shows which timer ended (its note, or its
 * duration when it has no note) and a "Turn Off" button. Each tap turns off one timer; it
 * closes itself once no timer is ringing any more.
 */
class RingingActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()

        setContent {
            MultiTimerTheme {
                // Back is disabled: the only way out is the Turn Off button.
                BackHandler(enabled = true) { }
                RingingScreen(onTurnOff = { startService(RingingService.dismissIntent(this)) })
            }
        }

        val repo = TimerRepository.get(this)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.timers.collect { list ->
                    if (list.none { it.state == TimerState.RINGING }) finish()
                }
            }
        }
    }
}

@Composable
private fun RingingScreen(onTurnOff: () -> Unit) {
    val context = LocalContext.current
    val timers by TimerRepository.get(context).timers.collectAsStateWithLifecycle()
    // The timer that the next "Turn Off" tap will dismiss (the one that rang first).
    val current = timers
        .filter { it.state == TimerState.RINGING }
        .minByOrNull { it.ringingSinceMillis }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        if (current != null) {
            Text(
                text = timerTitle(context, current),
                style = MaterialTheme.typography.displaySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(40.dp))
        }
        Button(
            onClick = onTurnOff,
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
        ) {
            Text(
                text = stringResource(R.string.turn_off),
                fontSize = 32.sp,
                style = MaterialTheme.typography.headlineMedium,
            )
        }
    }
}
