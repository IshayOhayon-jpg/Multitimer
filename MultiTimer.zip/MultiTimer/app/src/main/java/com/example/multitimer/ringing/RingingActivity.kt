package com.example.multitimer.ringing

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.multitimer.R
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.data.TimerState
import com.example.multitimer.ui.theme.MultiTimerTheme
import kotlinx.coroutines.launch

/**
 * Full-screen layover shown when a timer rings. Shows ONLY a "Turn Off" button.
 * It closes itself as soon as no timer is ringing any more.
 */
class RingingActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()

        setContent {
            MultiTimerTheme {
                // Back is disabled: the only way out is the Turn Off button.
                BackHandler(enabled = true) { }
                RingingScreen(onTurnOff = { startService(RingingService.dismissIntent(this)) })
            }
        }

        val repo = TimerRepository.get(this)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.timers.collect { list ->
                    if (list.none { it.state == TimerState.RINGING }) finish()
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun RingingScreen(onTurnOff: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        Button(
            onClick = onTurnOff,
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
        ) {
            Text(
                text = stringResource(R.string.turn_off),
                fontSize = 32.sp,
                style = MaterialTheme.typography.headlineMedium,
            )
        }
    }
}
