package com.example.multitimer.util

import android.content.Context
import android.util.Log
import com.example.multitimer.data.SettingsRepository
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * File-based debug logger.
 *
 * Writes ONLY while Debug Mode is enabled in Settings. When disabled, nothing is
 * written and the log directory is not even created. Nothing is sent to Logcat.
 *
 * Location: <app external files>/Documents/logs/multitimer-YYYY-MM-DD.log
 *   (typically /sdcard/Android/data/com.example.multitimer/files/Documents/logs/)
 */
object DebugLogger {

    @Volatile
    private var appContext: Context? = null

    private val executor: ExecutorService by lazy { Executors.newSingleThreadExecutor() }

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun logDirectory(context: Context): File? =
        context.getExternalFilesDir("Documents")?.let { File(it, "logs") }

    fun log(tag: String, message: String, error: Throwable? = null) {
        val ctx = appContext ?: return
        if (!SettingsRepository.get(ctx).debugMode.value) return

        val now = Date()
        executor.execute {
            // Re-check: the setting may have been switched off since this call was queued.
            if (!SettingsRepository.get(ctx).debugMode.value) return@execute
            try {
                val dir = logDirectory(ctx) ?: return@execute
                if (!dir.exists() && !dir.mkdirs()) return@execute
                val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(now)
                val text = buildString {
                    append(stamp).append(" [").append(tag).append("] ").append(message).append('\n')
                    if (error != null) append(Log.getStackTraceString(error)).append('\n')
                }
                File(dir, "multitimer-$day.log").appendText(text)
            } catch (_: Exception) {
                // Logging must never crash the app.
            }
        }
    }
}
