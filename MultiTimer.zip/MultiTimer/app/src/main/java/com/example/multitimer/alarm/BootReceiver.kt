package com.example.multitimer.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.util.DebugLogger

/**
 * AlarmManager forgets all alarms on reboot. Re-arm running timers. (Ringing is always
 * started from an alarm broadcast, never directly from BOOT_COMPLETED, because Android
 * does not allow starting a media-playback foreground service from there.)
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        DebugLogger.log("Boot", "boot completed; re-arming running timers")
        TimerRepository.get(context).rescheduleRunningAfterBoot()
    }
}
