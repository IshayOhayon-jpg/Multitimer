package com.example.multitimer.data

import android.content.Context
import com.example.multitimer.alarm.AlarmScheduler
import com.example.multitimer.util.DebugLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Single source of truth for timers. Shared by the UI, the alarm receiver and the
 * ringing service. State is persisted to SharedPreferences as JSON so timers survive
 * process death.
 */
class TimerRepository private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val lock = Any()

    private val _timers = MutableStateFlow(loadOrCreateDefaults())
    val timers: StateFlow<List<TimerItem>> = _timers.asStateFlow()

    // ---------------------------------------------------------------- queries

    fun ringingTimers(): List<TimerItem> =
        _timers.value.filter { it.state == TimerState.RINGING }.sortedBy { it.ringingSinceMillis }

    // -------------------------------------------------------------- mutations

    /** Create (id == null) or update a timer, reset it to [durationSeconds], and start it. */
    fun saveAndStart(id: Int?, label: String, durationSeconds: Long): Int {
        var resultId = -1
        mutate { list ->
            val idx = if (id == null) -1 else list.indexOfFirst { it.id == id }
            if (idx >= 0) {
                resultId = list[idx].id
                AlarmScheduler.cancel(appContext, resultId)
                list[idx] = list[idx].copy(
                    label = label,
                    durationSeconds = durationSeconds,
                    state = TimerState.IDLE,
                    remainingSeconds = durationSeconds,
                    endAtMillis = 0L,
                    ringingSinceMillis = 0L,
                )
            } else {
                resultId = nextId()
                list.add(TimerItem(id = resultId, label = label, durationSeconds = durationSeconds))
            }
            DebugLogger.log("Repo", "saved timer id=$resultId label='$label' duration=${durationSeconds}s")
        }
        start(resultId)
        return resultId
    }

    /** Start an IDLE timer or resume a PAUSED one. */
    fun start(id: Int) {
        mutate { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@mutate
            val t = list[idx]
            if (t.state != TimerState.IDLE && t.state != TimerState.PAUSED) return@mutate
            val remaining = if (t.state == TimerState.IDLE) t.durationSeconds else t.remainingSeconds
            if (remaining <= 0L) return@mutate
            val endAt = System.currentTimeMillis() + remaining * 1000L
            list[idx] = t.copy(
                state = TimerState.RUNNING,
                remainingSeconds = remaining,
                endAtMillis = endAt,
            )
            AlarmScheduler.schedule(appContext, id, endAt)
            DebugLogger.log("Repo", "start id=$id remaining=${remaining}s endAt=$endAt")
        }
    }

    fun pause(id: Int) {
        mutate { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@mutate
            val t = list[idx]
            if (t.state != TimerState.RUNNING) return@mutate
            val remaining = t.remainingAt(System.currentTimeMillis())
            AlarmScheduler.cancel(appContext, id)
            list[idx] = t.copy(state = TimerState.PAUSED, remainingSeconds = remaining, endAtMillis = 0L)
            DebugLogger.log("Repo", "pause id=$id remaining=${remaining}s")
        }
    }

    fun reset(id: Int) {
        mutate { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@mutate
            val t = list[idx]
            AlarmScheduler.cancel(appContext, id)
            list[idx] = t.copy(
                state = TimerState.IDLE,
                remainingSeconds = t.durationSeconds,
                endAtMillis = 0L,
                ringingSinceMillis = 0L,
            )
            DebugLogger.log("Repo", "reset id=$id")
        }
    }

    fun delete(id: Int) {
        mutate { list ->
            AlarmScheduler.cancel(appContext, id)
            list.removeAll { it.id == id }
            DebugLogger.log("Repo", "delete id=$id")
        }
    }

    /** Called when a timer's alarm fires. Returns true if the timer really started ringing. */
    fun markRinging(id: Int): Boolean {
        var ringing = false
        mutate { list ->
            val idx = list.indexOfFirst { it.id == id }
            if (idx < 0) return@mutate
            val t = list[idx]
            if (t.state != TimerState.RUNNING) return@mutate
            list[idx] = t.copy(
                state = TimerState.RINGING,
                remainingSeconds = 0L,
                endAtMillis = 0L,
                ringingSinceMillis = System.currentTimeMillis(),
            )
            ringing = true
            DebugLogger.log("Repo", "ringing id=$id")
        }
        return ringing
    }

    /**
     * Turn off the longest-ringing timer (it returns to IDLE with its full duration).
     * Returns how many timers are still ringing afterwards.
     */
    fun dismissOldestRinging(): Int {
        var remaining = 0
        mutate { list ->
            val oldest = list.filter { it.state == TimerState.RINGING }
                .minByOrNull { it.ringingSinceMillis }
            if (oldest != null) {
                val idx = list.indexOfFirst { it.id == oldest.id }
                list[idx] = oldest.copy(
                    state = TimerState.IDLE,
                    remainingSeconds = oldest.durationSeconds,
                    endAtMillis = 0L,
                    ringingSinceMillis = 0L,
                )
                DebugLogger.log("Repo", "dismissed id=${oldest.id}")
            }
            remaining = list.count { it.state == TimerState.RINGING }
        }
        return remaining
    }

    /**
     * After a reboot all alarms are gone. Re-arm every RUNNING timer; any timer whose end
     * time already passed is re-armed to fire almost immediately so it rings normally.
     */
    fun rescheduleRunningAfterBoot() {
        val now = System.currentTimeMillis()
        _timers.value.filter { it.state == TimerState.RUNNING }.forEach {
            AlarmScheduler.schedule(appContext, it.id, maxOf(it.endAtMillis, now + 2_000L))
            DebugLogger.log("Repo", "re-armed id=${it.id} after boot")
        }
    }

    // ------------------------------------------------------------ persistence

    private inline fun mutate(block: (MutableList<TimerItem>) -> Unit) {
        synchronized(lock) {
            val list = _timers.value.toMutableList()
            block(list)
            _timers.value = list
            prefs.edit().putString(KEY_TIMERS, encode(list)).apply()
        }
    }

    private fun nextId(): Int {
        val id = prefs.getInt(KEY_NEXT_ID, 1000)
        prefs.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }

    private fun loadOrCreateDefaults(): List<TimerItem> {
        val json = prefs.getString(KEY_TIMERS, null)
        if (json == null) {
            // Fresh install: 4 default timers (1, 5, 10, 15 minutes).
            val defaults = DEFAULT_DURATIONS_SECONDS.mapIndexed { i, d ->
                TimerItem(id = i + 1, durationSeconds = d)
            }
            prefs.edit()
                .putInt(KEY_NEXT_ID, 1000)
                .putString(KEY_TIMERS, encode(defaults))
                .apply()
            return defaults
        }
        return decode(json)
    }

    private fun encode(list: List<TimerItem>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("label", it.label)
                    .put("duration", it.durationSeconds)
                    .put("state", it.state.name)
                    .put("remaining", it.remainingSeconds)
                    .put("endAt", it.endAtMillis)
                    .put("ringingSince", it.ringingSinceMillis)
            )
        }
        return arr.toString()
    }

    private fun decode(json: String): List<TimerItem> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            TimerItem(
                id = o.getInt("id"),
                label = o.optString("label", ""),
                durationSeconds = o.getLong("duration"),
                state = runCatching { TimerState.valueOf(o.getString("state")) }
                    .getOrDefault(TimerState.IDLE),
                remainingSeconds = o.getLong("remaining"),
                endAtMillis = o.optLong("endAt", 0L),
                ringingSinceMillis = o.optLong("ringingSince", 0L),
            )
        }
    } catch (e: Exception) {
        DebugLogger.log("Repo", "Failed to decode stored timers", e)
        emptyList()
    }

    companion object {
        private const val PREFS = "timers_store"
        private const val KEY_TIMERS = "timers_json"
        private const val KEY_NEXT_ID = "next_id"
        private val DEFAULT_DURATIONS_SECONDS = listOf(60L, 300L, 600L, 900L)

        @Volatile
        private var instance: TimerRepository? = null

        fun get(context: Context): TimerRepository =
            instance ?: synchronized(this) {
                instance ?: TimerRepository(context.applicationContext).also { instance = it }
            }
    }
}
