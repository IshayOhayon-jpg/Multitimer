package com.example.multitimer.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.multitimer.MainActivity
import com.example.multitimer.R
import com.example.multitimer.alarm.TimerActionReceiver
import com.example.multitimer.data.TimerItem
import com.example.multitimer.data.TimerState
import com.example.multitimer.util.formatClock
import com.example.multitimer.util.timerTitle

/**
 * One silent, ongoing notification per RUNNING or PAUSED timer.
 * Running timers show a live countdown (drawn by the system, so no ticking service is
 * needed) plus Pause / Cancel; paused timers show Resume / Cancel.
 */
object TimerNotifier {

    const val ACTION_PAUSE = "com.example.multitimer.action.NOTIF_PAUSE"
    const val ACTION_RESUME = "com.example.multitimer.action.NOTIF_RESUME"
    const val ACTION_CANCEL = "com.example.multitimer.action.NOTIF_CANCEL"
    const val EXTRA_TIMER_ID = "timer_id"

    private const val CHANNEL_ID = "timer_running"
    private const val NOTIFICATION_BASE = 10_000

    /** Post/refresh notifications for active timers and remove them for all others. */
    fun sync(context: Context, timers: List<TimerItem>) {
        val nm = context.getSystemService(NotificationManager::class.java)
        ensureChannel(context, nm)
        timers.forEach { t ->
            when (t.state) {
                TimerState.RUNNING, TimerState.PAUSED -> nm.notify(notificationId(t.id), build(context, t))
                else -> nm.cancel(notificationId(t.id))
            }
        }
    }

    fun cancel(context: Context, timerId: Int) {
        context.getSystemService(NotificationManager::class.java).cancel(notificationId(timerId))
    }

    private fun notificationId(timerId: Int) = NOTIFICATION_BASE + timerId

    private fun ensureChannel(context: Context, nm: NotificationManager) {
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.notif_running_channel),
            NotificationManager.IMPORTANCE_LOW, // no sound, no pop-up
        ).apply {
            setSound(null, null)
            enableVibration(false)
        }
        nm.createNotificationChannel(channel)
    }

    private fun build(context: Context, t: TimerItem): android.app.Notification {
        val open = PendingIntent.getActivity(
            context, notificationId(t.id),
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_timer)
            .setContentTitle(timerTitle(context, t))
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(open)

        if (t.state == TimerState.RUNNING) {
            builder
                .setContentText(context.getString(R.string.notif_running))
                .setShowWhen(true)
                .setWhen(t.endAtMillis)
                .setUsesChronometer(true)
                .setChronometerCountDown(true)
                .addAction(0, context.getString(R.string.pause), action(context, t.id, ACTION_PAUSE, 1))
        } else {
            builder
                .setContentText(context.getString(R.string.notif_paused, formatClock(t.remainingSeconds)))
                .setShowWhen(false)
                .addAction(0, context.getString(R.string.resume), action(context, t.id, ACTION_RESUME, 2))
        }
        builder.addAction(0, context.getString(R.string.cancel), action(context, t.id, ACTION_CANCEL, 3))
        return builder.build()
    }

    private fun action(context: Context, timerId: Int, action: String, slot: Int): PendingIntent {
        val intent = Intent(context, TimerActionReceiver::class.java)
            .setAction(action)
            .putExtra(EXTRA_TIMER_ID, timerId)
        return PendingIntent.getBroadcast(
            context, timerId * 10 + slot, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
