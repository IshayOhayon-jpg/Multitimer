package com.example.multitimer

import android.app.Application
import com.example.multitimer.util.DebugLogger

class MultiTimerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        DebugLogger.init(this)
        DebugLogger.log("App", "Application created")
    }
}
