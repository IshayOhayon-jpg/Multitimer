package com.example.multitimer.util

import android.content.Context
import com.example.multitimer.R
import com.example.multitimer.data.TimerItem

/** "MM:SS", or "H:MM:SS" when an hour or more. */
fun formatClock(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/** The timer's note, or "<duration> timer" (e.g. "10:00 timer") when it has no note. */
fun timerTitle(context: Context, timer: TimerItem): String =
    timer.label.ifBlank { context.getString(R.string.timer_with_duration, formatClock(timer.durationSeconds)) }
