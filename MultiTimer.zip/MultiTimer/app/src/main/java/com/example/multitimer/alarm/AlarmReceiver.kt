package com.example.multitimer.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.multitimer.data.TimerRepository
import com.example.multitimer.ringing.RingingService
import com.example.multitimer.util.DebugLogger

/** Fired by AlarmManager when a timer reaches zero. Starts the ringing service. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != AlarmScheduler.ACTION_TIMER_FIRED) return
        val id = intent.getIntExtra(AlarmScheduler.EXTRA_TIMER_ID, -1)
        DebugLogger.log("Receiver", "alarm fired id=$id")
        if (id < 0) return

        if (TimerRepository.get(context).markRinging(id)) {
            // Exact-alarm apps may start a foreground service from this broadcast.
            ContextCompat.startForegroundService(context, RingingService.ringIntent(context))
        } else {
            DebugLogger.log("Receiver", "ignored stale alarm id=$id")
        }
    }
}
