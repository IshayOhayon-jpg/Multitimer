package com.example.multitimer.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.multitimer.R
import com.example.multitimer.data.TimerItem

private const val MAX_LABEL_LENGTH = 40

/**
 * Bottom-sheet layover to create or edit a timer: hours / minutes / seconds, an optional
 * label, and Clear / Set.
 *
 * "Set" saves the timer and starts it. If the label is empty, the user is first asked
 * whether they want to add a note (they can add one or skip).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimerConfigSheet(
    initial: TimerItem?,
    onDismiss: () -> Unit,
    onSet: (label: String, durationSeconds: Long) -> Unit,
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var hours by rememberSaveable { mutableStateOf(initial?.hours?.takeIf { it > 0 }?.toString().orEmpty()) }
    var minutes by rememberSaveable { mutableStateOf(initial?.minutes?.takeIf { it > 0 }?.toString().orEmpty()) }
    var seconds by rememberSaveable { mutableStateOf(initial?.seconds?.takeIf { it > 0 }?.toString().orEmpty()) }
    var label by rememberSaveable { mutableStateOf(initial?.label.orEmpty()) }
    var showNotePrompt by rememberSaveable { mutableStateOf(false) }

    val totalSeconds = (hours.toLongOrNull() ?: 0L) * 3600L +
        (minutes.toLongOrNull() ?: 0L) * 60L +
        (seconds.toLongOrNull() ?: 0L)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier
                .padding(horizontal = 24.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding()
                .imePadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = stringResource(if (initial == null) R.string.new_timer else R.string.edit_timer),
                style = MaterialTheme.typography.titleLarge,
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TimeField(hours, { hours = it.limitDigits(maxValue = 99) }, R.string.hours, Modifier.weight(1f))
                TimeField(minutes, { minutes = it.limitDigits(maxValue = 59) }, R.string.minutes, Modifier.weight(1f))
                TimeField(seconds, { seconds = it.limitDigits(maxValue = 59) }, R.string.seconds, Modifier.weight(1f))
            }

            OutlinedTextField(
                value = label,
                onValueChange = { label = it.take(MAX_LABEL_LENGTH) },
                label = { Text(stringResource(R.string.label_hint)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            Spacer(Modifier.height(4.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        hours = ""
                        minutes = ""
                        seconds = ""
                        label = ""
                    },
                    modifier = Modifier.weight(1f),
                ) { Text(stringResource(R.string.clear)) }

                Button(
                    onClick = {
                        if (label.isBlank()) showNotePrompt = true else onSet(label.trim(), totalSeconds)
                    },
                    enabled = totalSeconds > 0,
                    modifier = Modifier.weight(1f),
                ) { Text(stringResource(R.string.set)) }
            }
        }
    }

    if (showNotePrompt) {
        NotePromptDialog(
            onSave = { note -> showNotePrompt = false; onSet(note, totalSeconds) },
            onSkip = { showNotePrompt = false; onSet("", totalSeconds) },
            onDismiss = { showNotePrompt = false }, // back to the sheet, nothing saved
        )
    }
}

@Composable
private fun TimeField(
    value: String,
    onValueChange: (String) -> Unit,
    labelRes: Int,
    modifier: Modifier = Modifier,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(stringResource(labelRes)) },
        placeholder = { Text("00") },
        singleLine = true,
        textStyle = MaterialTheme.typography.titleLarge.copy(textAlign = TextAlign.Center),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = modifier,
    )
}

@Composable
private fun NotePromptDialog(
    onSave: (String) -> Unit,
    onSkip: () -> Unit,
    onDismiss: () -> Unit,
) {
    var note by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.note_prompt_title)) },
        text = {
            Column {
                Text(stringResource(R.string.note_prompt_body))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(MAX_LABEL_LENGTH) },
                    label = { Text(stringResource(R.string.note_field)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(note.trim()) }, enabled = note.isNotBlank()) {
                Text(stringResource(R.string.note_save))
            }
        },
        dismissButton = {
            TextButton(onClick = onSkip) { Text(stringResource(R.string.note_skip)) }
        },
    )
}

/** Keep only digits (max 2) and clamp the numeric value to [maxValue]. */
private fun String.limitDigits(maxValue: Int): String {
    val digits = filter(Char::isDigit).take(2)
    val value = digits.toIntOrNull() ?: return digits
    return if (value > maxValue) maxValue.toString() else digits
}
