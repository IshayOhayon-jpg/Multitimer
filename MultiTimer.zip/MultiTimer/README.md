# Multi Timer (Android, Kotlin, Jetpack Compose, Material 3)

Offline multi-timer app. Package `com.example.multitimer`, minSdk 33, target/compile SDK 35.
No network permissions are declared and there are no network calls or cloud dependencies.

## Build the APK

Prerequisites: JDK 17 and the Android SDK (platform 35). The easiest route is Android Studio.

### Option A: Android Studio (easiest)
1. File > Open > select this folder. Let Gradle sync (this also creates the Gradle wrapper).
2. Build > Build APK(s). Or run on your phone with USB debugging.

### Option B: command line
Gradle 8.9 or newer must be installed once to create the wrapper:

```bash
cd MultiTimer
echo "sdk.dir=/path/to/Android/Sdk" > local.properties   # skip if ANDROID_HOME is set
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`. It is signed with the auto-generated
debug key and can be installed directly:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Signed release APK
```bash
keytool -genkeypair -v -keystore release-keystore.jks -alias multitimer \
        -keyalg RSA -keysize 2048 -validity 10000
cp keystore.properties.example keystore.properties   # then edit passwords/alias
./gradlew assembleRelease
```
Output: `app/build/outputs/apk/release/app-release.apk` (signed).
Without `keystore.properties` the release APK is `app-release-unsigned.apk` and cannot be
installed until you sign it (e.g. with `apksigner`).

## How it works
- Timers store a wall-clock end time. Each running timer has one exact `AlarmManager`
  alarm (`USE_EXACT_ALARM`, `setExactAndAllowWhileIdle`), so timers keep running when the
  app is backgrounded or closed. A boot receiver re-arms running timers after a reboot.
- On fire, `AlarmReceiver` starts `RingingService` (foreground, media playback). It loops the
  chosen notification sound on the alarm audio stream and posts a full-screen-intent
  notification that opens `RingingActivity` (only a "Turn Off" button).
- "Turn Off" dismisses one ringing timer at a time; the sound continues until all are off.
- Set = save and start. If the label is empty you are asked whether to add a note (Add / Skip).
- While timers run, each has an ongoing notification with its note (or duration), a live countdown and Pause/Cancel buttons (Resume/Cancel while paused).
- The ringing screen shows which timer ended (its note, or e.g. "10:00 timer").
- Settings: notification sound (system picker, defaults to system default) and Debug mode.
- Debug mode logs only while enabled, to
  `/sdcard/Android/data/com.example.multitimer/files/Documents/logs/multitimer-YYYY-MM-DD.log`.
  When off, nothing is written (and nothing goes to Logcat).

## Notes
- Grant the notification permission on first launch, otherwise the lock-screen ringing
  screen cannot appear (sound still plays).
- Android 14+ file managers may hide `Android/data`; use a file manager that allows it, or
  `adb pull /sdcard/Android/data/com.example.multitimer/files/Documents/logs`.
- Additions beyond the spec: a small delete (x) button on each timer card, a boot receiver,
  and a settings (gear) icon placed left of the "+" so "+" stays top-right.
- This code was written without an Android SDK available, so it has not been compiled here.
  If Gradle reports a compile error, send it to me and I'll fix it.
